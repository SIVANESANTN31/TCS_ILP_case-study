package com.electrohub.service;

import java.util.List;
import java.util.stream.Collectors;

import com.electrohub.enums.Category;
import com.electrohub.enums.ProductStatus;
import com.electrohub.model.Product;
import com.electrohub.repository.ProductRepository;

public class CustomerCatalogService {

    private final ProductRepository repository =
            ProductRepository.getInstance();

    public List<Product> viewCatalog() {

        return repository.findAll()
                .stream()
                .filter(product ->
                        product.getStatus()
                                == ProductStatus.ACTIVE)
                .collect(Collectors.toList());
    }

    public Product getProductDetails(
            int productId) {

        return repository.findById(productId);
    }

    public List<Product> searchProducts(
            String keyword) {

        return repository.findAll()
                .stream()
                .filter(product ->
                        product.getProductName()
                                .toLowerCase()
                                .contains(
                                        keyword
                                                .toLowerCase()
                                ))
                .collect(Collectors.toList());
    }

    public List<Product> filterByCategory(
            Category category) {

        return repository.findAll()
                .stream()
                .filter(product ->
                        product.getCategory()
                                == category
                                &&
                                product.getStatus()
                                        ==
                                        ProductStatus.ACTIVE
                )
                .collect(Collectors.toList());
    }
}