package com.electrohub.service;

import java.util.List;

import com.electrohub.model.AuditLog;
import com.electrohub.repository.AuditLogRepository;
import com.electrohub.util.CsvExporter;

public class AuditService {

    private final AuditLogRepository
            auditRepository =
            AuditLogRepository.getInstance();

    public void viewAuditLogs() {

        List<AuditLog> logs =
                auditRepository.findAll();

        if (logs.isEmpty()) {

            System.out.println(
                    "No Audit Logs Found."
            );

            return;
        }

        logs.forEach(System.out::println);
    }

    public void exportAuditLogs() {

        CsvExporter.exportAuditLogs(
                auditRepository.findAll(),
                "audit_logs.csv"
        );
    }
}