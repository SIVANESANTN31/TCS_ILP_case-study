package com.electrohub.service;

import com.electrohub.model.CartItem;
import com.electrohub.model.Order;

public class InvoiceService {

    public void generateInvoice(
            Order order) {

        if (order == null) {

            System.out.println(
                    "Invoice Generation Failed."
            );

            return;
        }

        System.out.println();
        System.out.println(
                "===================================="
        );
        System.out.println(
                "          ELECTRO HUB"
        );
        System.out.println(
                "===================================="
        );

        System.out.println(
                "Order ID : "
                        + order.getOrderId()
        );

        System.out.println(
                "Customer : "
                        + order.getCustomer()
                               .getUsername()
        );

        System.out.println(
                "Order Date : "
                        + order.getOrderDate()
        );

        System.out.println();
        System.out.println(
                "Products"
        );

        for (CartItem item :
                order.getItems()) {

            System.out.println(
                    item.getProduct()
                            .getProductName()
                            + " x "
                            + item.getQuantity()
            );
        }

        System.out.println();
        System.out.println(
                "Payment Mode : "
                        + order.getPayment()
                               .getPaymentMode()
        );

        System.out.println(
                "Total Price : "
                         + order.getPayment()
                                .getTotalPrice()
        );

        System.out.println(
                "GST : "
                        + order.getPayment()
                               .getGstPrice()
        );

        System.out.println(
                "Final Price : "
                        + order.getPayment()
                               .getFinalPrice()
        );

        System.out.println(
                "===================================="
        );
    }
}