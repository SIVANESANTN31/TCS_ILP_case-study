package com.electrohub.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import com.electrohub.enums.AuditModule;
import com.electrohub.enums.AuditOperation;
import com.electrohub.enums.CustomerStatus;
import com.electrohub.model.AuditLog;
import com.electrohub.model.Customer;
import com.electrohub.repository.AuditLogRepository;
import com.electrohub.repository.CustomerRepository;
import com.electrohub.util.DateTimeUtil;
import com.electrohub.util.IdGenerator;
import com.electrohub.util.ValidationUtil;

public class CustomerService {

    private final CustomerRepository customerRepository =
            CustomerRepository.getInstance();

    private final AuditLogRepository auditLogRepository =
            AuditLogRepository.getInstance();

    /**
     * US10 - Customer Registration
     */
    public boolean registerCustomer(String username,
                                    String email,
                                    LocalDate dob,
                                    String password,
                                    String mobile,
                                    String address) {

        if (!ValidationUtil.isValidUsername(username)) {

            System.out.println("Invalid Username.");
            return false;
        }

        if (!ValidationUtil.isValidEmail(email)) {

            System.out.println("Invalid Email.");
            return false;
        }

        if (!ValidationUtil.isValidPassword(password)) {

            System.out.println("Invalid Password.");
            return false;
        }

        if (!ValidationUtil.isValidMobile(mobile)) {

            System.out.println("Invalid Mobile Number.");
            return false;
        }

        if (!ValidationUtil.isAdult(dob)) {

            System.out.println("Customer must be above 18 years.");
            return false;
        }

        if (customerRepository.findByEmail(email) != null) {

            System.out.println("Email already exists.");
            return false;
        }

        LocalDateTime now =
                DateTimeUtil.getCurrentDateTime();

        Customer customer =
                new Customer(
                        IdGenerator.generateCustomerId(),
                        username,
                        email,
                        dob,
                        password,
                        Long.parseLong(mobile),
                        address,
                        CustomerStatus.ACTIVE,
                        now,
                        now
                );

        customerRepository.save(customer);

        saveAuditLog(
                AuditModule.CUSTOMER,
                AuditOperation.INSERT,
                username
        );

        System.out.println("Customer Registered Successfully.");
        System.out.println(
                "Generated Customer ID : "
                        + customer.getCustomerId()
        );

        return true;
    }

    /**
     * US06 - View Customers
     */
    public void viewAllCustomers() {

        List<Customer> customers =
                customerRepository.findAll();

        if (customers.isEmpty()) {

            System.out.println("No Customers Found.");
            return;
        }

        customers.forEach(System.out::println);
    }

    /**
     * US06 - Activate Customer
     */
    public boolean activateCustomer(int customerId,
                                    String adminName) {

        Customer customer =
                customerRepository.findById(customerId);

        if (customer == null) {

            System.out.println("Customer not found.");
            return false;
        }

        customer.setStatus(CustomerStatus.ACTIVE);

        customer.setModifiedOn(
                DateTimeUtil.getCurrentDateTime()
        );

        customerRepository.update(customer);

        saveAuditLog(
                AuditModule.CUSTOMER,
                AuditOperation.UPDATE,
                adminName
        );

        System.out.println("Customer Activated Successfully.");

        return true;
    }

    /**
     * US19 - Update Profile
     */
    public boolean updateProfile(int customerId,
                                 String email,
                                 String password,
                                 String mobile,
                                 LocalDate dob,
                                 String address) {

        Customer customer =
                customerRepository.findById(customerId);

        if (customer == null) {

            System.out.println("Customer not found.");
            return false;
        }

        if (!ValidationUtil.isValidEmail(email)) {

            System.out.println("Invalid Email.");
            return false;
        }

        if (!ValidationUtil.isValidPassword(password)) {

            System.out.println("Invalid Password.");
            return false;
        }

        if (!ValidationUtil.isValidMobile(mobile)) {

            System.out.println("Invalid Mobile Number.");
            return false;
        }

        if (!ValidationUtil.isAdult(dob)) {

            System.out.println("Age must be greater than 18.");
            return false;
        }

        customer.setEmail(email);
        customer.setPassword(password);
        customer.setMobile(Long.parseLong(mobile));
        customer.setDob(dob);
        customer.setAddress(address);

        customer.setModifiedOn(
                DateTimeUtil.getCurrentDateTime()
        );

        customerRepository.update(customer);

        saveAuditLog(
                AuditModule.CUSTOMER,
                AuditOperation.UPDATE,
                customer.getUsername()
        );

        System.out.println(
                "Profile Updated Successfully."
        );

        return true;
    }

    /**
     * US19 - Deactivate Customer
     */
    public boolean deactivateCustomer(int customerId) {

        Customer customer =
                customerRepository.findById(customerId);

        if (customer == null) {

            System.out.println("Customer not found.");
            return false;
        }

        customer.setStatus(
                CustomerStatus.INACTIVE
        );

        customer.setModifiedOn(
                DateTimeUtil.getCurrentDateTime()
        );

        customerRepository.update(customer);

        saveAuditLog(
                AuditModule.CUSTOMER,
                AuditOperation.UPDATE,
                customer.getUsername()
        );

        System.out.println(
                "Customer Account Deactivated."
        );

        return true;
    }

    /**
     * Find customer by email
     */
    public Customer getCustomerByEmail(
            String email) {

        return customerRepository.findByEmail(email);
    }

    /**
     * Find customer by id
     */
    public Customer getCustomerById(
            int customerId) {

        return customerRepository.findById(customerId);
    }

    /**
     * Internal Audit Utility
     */
    private void saveAuditLog(
            AuditModule module,
            AuditOperation operation,
            String username) {

        LocalDateTime now =
                DateTimeUtil.getCurrentDateTime();

        AuditLog auditLog =
                new AuditLog(
                        IdGenerator.generateAuditId(),
                        module,
                        operation,
                        now,
                        username,
                        now,
                        username
                );

        auditLogRepository.save(auditLog);
    }
}