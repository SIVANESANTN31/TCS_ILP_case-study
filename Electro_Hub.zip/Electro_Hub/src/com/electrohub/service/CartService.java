package com.electrohub.service;

import java.util.List;

import com.electrohub.enums.ProductStatus;
import com.electrohub.model.Cart;
import com.electrohub.model.CartItem;
import com.electrohub.model.Product;
import com.electrohub.repository.CartRepository;
import com.electrohub.repository.ProductRepository;
import com.electrohub.util.GSTCalculator;

public class CartService {

    private final CartRepository cartRepository =
            CartRepository.getInstance();

    private final ProductRepository productRepository =
            ProductRepository.getInstance();

    public boolean addToCart(int customerId,
                             int productId,
                             int quantity) {

        Product product =
                productRepository.findById(productId);

        if (product == null) {

            System.out.println("Product Not Found.");
            return false;
        }

        if (product.getStatus() != ProductStatus.ACTIVE) {

            System.out.println("Product Inactive.");
            return false;
        }

        if (quantity <= 0) {

            System.out.println("Invalid Quantity.");
            return false;
        }

        if (product.getStock() < quantity) {

            System.out.println("Insufficient Stock.");
            return false;
        }

        Cart cart;

        if (cartRepository.cartExists(customerId)) {

            cart = cartRepository.getCart(customerId);
        } else {

            cart = new Cart(customerId);

            cartRepository.saveCart(customerId, cart);
        }

        List<CartItem> items = cart.getItems();

        for (CartItem item : items) {

            if (item.getProduct().getProductId()
                    == productId) {

                item.setQuantity(
                        item.getQuantity() + quantity
                );

                System.out.println(
                        "Quantity Updated."
                );

                return true;
            }
        }

        CartItem cartItem =
                new CartItem(product, quantity);

        items.add(cartItem);

        System.out.println(
                "Product Added To Cart Successfully."
        );

        return true;
    }

    public boolean removeFromCart(int customerId,
                                  int productId) {

        Cart cart =
                cartRepository.getCart(customerId);

        if (cart == null) {

            System.out.println("Cart Empty.");
            return false;
        }

        boolean removed =
                cart.getItems()
                        .removeIf(item ->
                                item.getProduct()
                                        .getProductId()
                                        == productId);

        if (removed) {

            System.out.println(
                    "Product Removed Successfully."
            );
        }

        return removed;
    }

    public void viewCart(int customerId) {

        Cart cart =
                cartRepository.getCart(customerId);

        if (cart == null
                || cart.getItems().isEmpty()) {

            System.out.println(
                    "No Products Found In Cart."
            );

            return;
        }

        System.out.println();
        System.out.println(
                "========== CART =========="
        );

        int totalQuantity = 0;

        for (CartItem item :
                cart.getItems()) {

            System.out.println(
                    item.getProduct().getProductName()
                            + " | Qty : "
                            + item.getQuantity()
                            + " | Price : "
                            + item.getItemTotal()
            );

            totalQuantity += item.getQuantity();
        }

        double totalPrice =
                getTotalPrice(customerId);

        double gst =
                GSTCalculator.calculateGST(
                        totalPrice
                );

        double finalPrice =
                GSTCalculator.calculateFinalPrice(
                        totalPrice
                );

        System.out.println();
        System.out.println(
                "Total Quantity : "
                        + totalQuantity
        );

        System.out.println(
                "Total Price : "
                        + totalPrice
        );

        System.out.println(
                "GST : "
                        + gst
        );

        System.out.println(
                "Final Price : "
                        + finalPrice
        );
    }

    public void clearCart(int customerId) {

        cartRepository.removeCart(customerId);

        System.out.println(
                "Cart Cleared Successfully."
        );
    }

    public Cart getCart(int customerId) {

        return cartRepository.getCart(customerId);
    }

    public double getTotalPrice(int customerId) {

        Cart cart =
                cartRepository.getCart(customerId);

        if (cart == null) {

            return 0;
        }

        return cart.calculateTotalPrice();
    }

    public double getGST(int customerId) {

        return GSTCalculator.calculateGST(
                getTotalPrice(customerId)
        );
    }

    public double getFinalPrice(int customerId) {

        return GSTCalculator.calculateFinalPrice(
                getTotalPrice(customerId)
        );
    }
}