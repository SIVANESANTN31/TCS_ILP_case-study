package com.electrohub.service;

import com.electrohub.enums.CustomerStatus;
import com.electrohub.enums.Role;
import com.electrohub.model.Customer;
import com.electrohub.model.UserSession;
import com.electrohub.repository.CustomerRepository;

public class AuthService {

    private static final String ADMIN_USERNAME = "admin";
    private static final String ADMIN_PASSWORD = "admin123";

    private final CustomerRepository customerRepository =
            CustomerRepository.getInstance();

    private UserSession currentSession;

    public UserSession adminLogin(String username,
                                  String password) {

        if (username == null || password == null) {

            System.out.println("Username and Password cannot be empty.");
            return null;
        }

        if (ADMIN_USERNAME.equals(username)
                && ADMIN_PASSWORD.equals(password)) {

            currentSession = new UserSession(
                    username,
                    Role.ADMIN,
                    true
            );

            System.out.println("Admin Login Successful.");

            return currentSession;
        }

        System.out.println("Invalid Admin Credentials.");
        return null;
    }

    public UserSession customerLogin(String email,
                                     String password) {

        Customer customer =
                customerRepository.findByEmail(email);

        if (customer == null) {

            System.out.println("Customer not found.");
            return null;
        }

        if (customer.getStatus()
                == CustomerStatus.INACTIVE) {

            System.out.println("Customer account is inactive.");
            return null;
        }

        if (!customer.getPassword().equals(password)) {

            System.out.println("Invalid password.");
            return null;
        }

        currentSession = new UserSession(
                customer.getUsername(),
                Role.CUSTOMER,
                true
        );

        System.out.println("Customer Login Successful.");

        return currentSession;
    }

    public void logout() {

        if (currentSession == null) {

            System.out.println("No active session found.");
            return;
        }

        String username =
                currentSession.getUsername();

        Role role =
                currentSession.getRole();

        currentSession.setLoggedIn(false);
        currentSession = null;

        System.out.println(
                role + " " + username +
                " Logged Out Successfully."
        );
    }

    public boolean isLoggedIn() {

        return currentSession != null
                && currentSession.isLoggedIn();
    }

    public UserSession getCurrentSession() {

        return currentSession;
    }
}