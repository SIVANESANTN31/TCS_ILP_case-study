package com.electrohub.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import com.electrohub.enums.AuditModule;
import com.electrohub.enums.AuditOperation;
import com.electrohub.enums.Category;
import com.electrohub.enums.ProductStatus;
import com.electrohub.model.AuditLog;
import com.electrohub.model.Product;
import com.electrohub.repository.AuditLogRepository;
import com.electrohub.repository.ProductRepository;
import com.electrohub.util.DateTimeUtil;
import com.electrohub.util.IdGenerator;

public class ProductService {

    private final ProductRepository productRepository =
            ProductRepository.getInstance();

    private final AuditLogRepository auditLogRepository =
            AuditLogRepository.getInstance();

    /**
     * US02 - Add Product
     */
    public boolean addProduct(String productName,
                              String productImage,
                              double price,
                              int stock,
                              Category category,
                              String adminName) {

        if (productName == null || productName.trim().isEmpty()) {
            System.out.println("Product name cannot be empty.");
            return false;
        }

        if (price <= 0) {
            System.out.println("Price must be greater than zero.");
            return false;
        }

        if (stock < 0) {
            System.out.println("Stock cannot be negative.");
            return false;
        }

        LocalDateTime now =
                DateTimeUtil.getCurrentDateTime();

        Product product = new Product(
                IdGenerator.generateProductId(),
                productName,
                productImage,
                price,
                stock,
                category,
                ProductStatus.ACTIVE,
                now,
                now
        );

        productRepository.save(product);

        saveAuditLog(
                AuditModule.PRODUCT,
                AuditOperation.INSERT,
                adminName
        );

        System.out.println("Product Added Successfully.");
        System.out.println("Generated Product ID : "
                + product.getProductId());

        return true;
    }

    /**
     * US03 - Soft Delete Product
     */
    public boolean softDeleteProduct(int productId,
                                     String adminName) {

        Product product =
                productRepository.findById(productId);

        if (product == null) {

            System.out.println("Product not found.");
            return false;
        }

        product.setStatus(ProductStatus.INACTIVE);

        product.setModifiedOn(
                DateTimeUtil.getCurrentDateTime()
        );

        productRepository.update(product);

        saveAuditLog(
                AuditModule.PRODUCT,
                AuditOperation.DELETE,
                adminName
        );

        System.out.println("Product marked as INACTIVE.");

        return true;
    }

    /**
     * US04 - View All Products
     */
    public void viewAllProducts() {

        List<Product> products =
                productRepository.findAll();

        if (products.isEmpty()) {

            System.out.println("No Products Available.");
            return;
        }

        products.forEach(System.out::println);
    }

    /**
     * US04 - Filter by Status
     */
    public List<Product> filterByStatus(ProductStatus status) {

        List<Product> result = new ArrayList<>();

        for (Product product :
                productRepository.findAll()) {

            if (product.getStatus() == status) {
                result.add(product);
            }
        }

        return result;
    }

    /**
     * US04 - Filter by Category
     */
    public List<Product> filterByCategory(
            Category category) {

        List<Product> result = new ArrayList<>();

        for (Product product :
                productRepository.findAll()) {

            if (product.getCategory() == category) {
                result.add(product);
            }
        }

        return result;
    }

    /**
     * US04 - Filter by Created Date
     */
    public List<Product> filterByDate(
            LocalDateTime fromDate,
            LocalDateTime toDate) {

        List<Product> result = new ArrayList<>();

        for (Product product :
                productRepository.findAll()) {

            LocalDateTime createdDate =
                    product.getCreatedOn();

            if ((createdDate.isEqual(fromDate)
                    || createdDate.isAfter(fromDate))
                    &&
                    (createdDate.isEqual(toDate)
                    || createdDate.isBefore(toDate))) {

                result.add(product);
            }
        }

        return result;
    }

    /**
     * US04 - Sort by Price Ascending
     */
    public List<Product> sortByPriceAsc() {

        List<Product> products =
                new ArrayList<>(
                        productRepository.findAll()
                );

        products.sort(
                Comparator.comparingDouble(
                        Product::getPrice
                )
        );

        return products;
    }

    /**
     * US04 - Sort by Price Descending
     */
    public List<Product> sortByPriceDesc() {

        List<Product> products =
                new ArrayList<>(
                        productRepository.findAll()
                );

        products.sort(
                Comparator.comparingDouble(
                        Product::getPrice
                ).reversed()
        );

        return products;
    }

    /**
     * US04 - Sort by Category
     */
    public List<Product> sortByCategory() {

        List<Product> products =
                new ArrayList<>(
                        productRepository.findAll()
                );

        products.sort(
                Comparator.comparing(
                        Product::getCategory
                )
        );

        return products;
    }

    /**
     * US05 - Manual Price Update
     */
    public boolean updatePrice(int productId,
                               double newPrice,
                               String adminName) {

        Product product =
                productRepository.findById(productId);

        if (product == null) {

            System.out.println("Product not found.");
            return false;
        }

        if (newPrice <= 0) {

            System.out.println("Price must be greater than 0.");
            return false;
        }

        product.setPrice(newPrice);

        product.setModifiedOn(
                DateTimeUtil.getCurrentDateTime()
        );

        productRepository.update(product);

        saveAuditLog(
                AuditModule.PRODUCT,
                AuditOperation.UPDATE,
                adminName
        );

        System.out.println("Price updated successfully.");

        return true;
    }

    /**
     * US05 - Dynamic Pricing Rule
     */
    public boolean applyDynamicPricing(int productId,
                                       String adminName) {

        Product product =
                productRepository.findById(productId);

        if (product == null) {

            System.out.println("Product not found.");
            return false;
        }

        double currentPrice =
                product.getPrice();

        if (product.getStock() < 10) {

            currentPrice =
                    currentPrice +
                    (currentPrice * 0.05);

            product.setPrice(currentPrice);

            System.out.println(
                    "Price Increased by 5%"
            );
        }

        else if (product.getStock() > 100) {

            currentPrice =
                    currentPrice -
                    (currentPrice * 0.05);

            product.setPrice(currentPrice);

            System.out.println(
                    "Price Decreased by 5%"
            );
        }

        else {

            System.out.println(
                    "No Dynamic Pricing Applicable."
            );

            return false;
        }

        product.setModifiedOn(
                DateTimeUtil.getCurrentDateTime()
        );

        productRepository.update(product);

        saveAuditLog(
                AuditModule.PRODUCT,
                AuditOperation.UPDATE,
                adminName
        );

        return true;
    }

    /**
     * Search Product By ID
     */
    public Product getProductById(int productId) {

        return productRepository.findById(productId);
    }

    /**
     * Search Product By Name
     */
    public Product getProductByName(
            String productName) {

        return productRepository.findByName(
                productName
        );
    }

    /**
     * Save Audit Log
     */
    private void saveAuditLog(
            AuditModule module,
            AuditOperation operation,
            String user) {

        LocalDateTime now =
                DateTimeUtil.getCurrentDateTime();

        AuditLog auditLog =
                new AuditLog(
                        IdGenerator.generateAuditId(),
                        module,
                        operation,
                        now,
                        user,
                        now,
                        user
                );

        auditLogRepository.save(auditLog);
    }
}