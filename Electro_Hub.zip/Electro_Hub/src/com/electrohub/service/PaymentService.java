package com.electrohub.service;

import java.time.LocalDateTime;
import java.util.ArrayList;

import com.electrohub.enums.AuditModule;
import com.electrohub.enums.AuditOperation;
import com.electrohub.enums.OrderStatus;
import com.electrohub.enums.PaymentMode;
import com.electrohub.enums.PaymentStatus;
import com.electrohub.model.AuditLog;
import com.electrohub.model.Cart;
import com.electrohub.model.Customer;
import com.electrohub.model.Order;
import com.electrohub.model.Payment;
import com.electrohub.repository.AuditLogRepository;
import com.electrohub.repository.OrderRepository;
import com.electrohub.repository.PaymentRepository;
import com.electrohub.util.DateTimeUtil;
import com.electrohub.util.IdGenerator;

public class PaymentService {

    private static final double MAX_PAYMENT_LIMIT =
            100000.00;

    private final PaymentRepository paymentRepository =
            PaymentRepository.getInstance();

    private final OrderRepository orderRepository =
            OrderRepository.getInstance();

    private final AuditLogRepository auditRepository =
            AuditLogRepository.getInstance();

    private final CartService cartService =
            new CartService();

    public Order checkout(Customer customer,
                          PaymentMode paymentMode) {

        Cart cart =
                cartService.getCart(
                        customer.getCustomerId());

        if (cart == null ||
                cart.getItems().isEmpty()) {

            System.out.println(
                    "Cart is empty."
            );

            return null;
        }

        double totalPrice =
                cartService.getTotalPrice(
                        customer.getCustomerId()
                );

        double gst =
                cartService.getGST(
                        customer.getCustomerId()
                );

        double finalPrice =
                cartService.getFinalPrice(
                        customer.getCustomerId()
                );

        if (finalPrice >
                MAX_PAYMENT_LIMIT) {

            System.out.println(
                    "Maximum payment limit exceeded."
            );

            return null;
        }

        LocalDateTime now =
                DateTimeUtil.getCurrentDateTime();

        Payment payment =
                new Payment(
                        IdGenerator.generatePaymentId(),
                        paymentMode,
                        cart.getItems().size(),
                        totalPrice,
                        gst,
                        finalPrice,
                        PaymentStatus.COMPLETED,
                        now,
                        now
                );

        paymentRepository.save(payment);

        Order order =
                new Order(
                        IdGenerator.generateOrderId(),
                        customer,
                        new ArrayList<>(
                                cart.getItems()
                        ),
                        payment,
                        OrderStatus.COMPLETED,
                        now
                );

        orderRepository.save(order);

        saveAudit(
                customer.getUsername()
        );

        cartService.clearCart(
                customer.getCustomerId()
        );

        System.out.println(
                "Payment Successful."
        );

        System.out.println(
                "Order Created Successfully."
        );

        return order;
    }

    private void saveAudit(String username) {

        LocalDateTime now =
                DateTimeUtil.getCurrentDateTime();

        AuditLog log =
                new AuditLog(
                        IdGenerator.generateAuditId(),
                        AuditModule.PAYMENT,
                        AuditOperation.INSERT,
                        now,
                        username,
                        now,
                        username
                );

        auditRepository.save(log);
    }
}