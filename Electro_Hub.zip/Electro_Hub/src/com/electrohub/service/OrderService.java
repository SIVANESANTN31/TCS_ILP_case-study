package com.electrohub.service;

import java.util.Comparator;
import java.util.List;

import com.electrohub.model.Order;
import com.electrohub.repository.OrderRepository;

public class OrderService {

    private final OrderRepository orderRepository =
            OrderRepository.getInstance();

    public void viewAllOrders() {

        List<Order> orders =
                orderRepository.findAll();

        if (orders.isEmpty()) {

            System.out.println(
                    "No Orders Found."
            );

            return;
        }

        orders.forEach(System.out::println);
    }

    public void viewOrderHistory(
            int customerId) {

        List<Order> orders =
                orderRepository
                        .findByCustomerId(
                                customerId);

        orders.sort(
                Comparator.comparing(
                        Order::getOrderDate
                ).reversed()
        );

        if (orders.isEmpty()) {

            System.out.println(
                    "No Orders Found."
            );

            return;
        }

        orders.forEach(System.out::println);
    }
}