package com.electrohub.enums;

public enum PaymentMode {

    UPI,
    DEBIT_CARD,
    CREDIT_CARD
}