package com.electrohub.enums;

public enum PaymentStatus {

    PENDING,
    COMPLETED,
    FAILED
}