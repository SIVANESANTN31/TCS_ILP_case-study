package com.electrohub.enums;

public enum AuditModule {

    CUSTOMER,
    PRODUCT,
    PAYMENT
}