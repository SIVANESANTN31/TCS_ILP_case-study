package com.electrohub.enums;

public enum CustomerStatus {

    ACTIVE,
    INACTIVE
}