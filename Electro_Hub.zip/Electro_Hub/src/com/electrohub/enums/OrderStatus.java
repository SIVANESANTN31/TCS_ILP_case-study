package com.electrohub.enums;

public enum OrderStatus {

    PENDING,
    COMPLETED
}