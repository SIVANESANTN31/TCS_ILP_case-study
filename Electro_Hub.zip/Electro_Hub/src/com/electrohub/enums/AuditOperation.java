package com.electrohub.enums;

public enum AuditOperation {

    INSERT,
    UPDATE,
    DELETE
}