package com.electrohub.enums;

public enum Category {

    SMART_PHONE,
    LAPTOP,
    PC,
    SMART_WATCH,
    TABLET
}