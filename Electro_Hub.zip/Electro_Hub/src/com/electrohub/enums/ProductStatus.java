package com.electrohub.enums;

public enum ProductStatus {

    ACTIVE,
    INACTIVE
}