package com.electrohub.enums;

public enum Role {
    ADMIN,
    CUSTOMER
}