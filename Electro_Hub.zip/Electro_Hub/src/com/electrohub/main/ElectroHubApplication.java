package com.electrohub.main;

import com.electrohub.menu.MainMenu;
import com.electrohub.util.DataInitializer;

public class ElectroHubApplication {

    public static void main(String[] args) {

        try {

            // Load default products
            DataInitializer.initializeProducts();

            // Start Application
            MainMenu mainMenu = new MainMenu();

            mainMenu.show();

        } catch (Exception e) {

            System.out.println(
                    "Application failed to start."
            );

            System.out.println(
                    "Reason : " + e.getMessage()
            );
        }
    }
}