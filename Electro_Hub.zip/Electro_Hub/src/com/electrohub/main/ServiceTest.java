package com.electrohub.main;

import java.time.LocalDate;

import com.electrohub.service.AuthService;
import com.electrohub.service.CustomerService;

public class ServiceTest {

    public static void main(String[] args) {

        CustomerService customerService =
                new CustomerService();

        customerService.registerCustomer(
                "Mohamed",
                "mohamed@gmail.com",
                LocalDate.of(2000, 5, 20),
                "Pass@123",
                "9876543210",
                "Chennai"
        );

        AuthService authService =
                new AuthService();

        authService.customerLogin(
                "mohamed@gmail.com",
                "Pass@123"
        );

        authService.logout();
    }
}