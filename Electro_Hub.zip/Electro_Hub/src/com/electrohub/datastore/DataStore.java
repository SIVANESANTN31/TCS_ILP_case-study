package com.electrohub.datastore;

import java.util.ArrayList;
import java.util.List;

import com.electrohub.model.AuditLog;
import com.electrohub.model.Customer;
import com.electrohub.model.Order;
import com.electrohub.model.Payment;
import com.electrohub.model.Product;

public class DataStore {

    private DataStore() {
    }

    public static final List<Customer> customers = new ArrayList<>();

    public static final List<Product> products = new ArrayList<>();

    public static final List<Payment> payments = new ArrayList<>();

    public static final List<Order> orders = new ArrayList<>();

    public static final List<AuditLog> auditLogs = new ArrayList<>();
}
