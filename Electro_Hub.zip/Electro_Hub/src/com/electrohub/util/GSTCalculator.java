package com.electrohub.util;

public class GSTCalculator {

    private static final double GST_RATE = 0.02;

    private GSTCalculator() {
    }

    public static double calculateGST(double totalPrice) {
        return totalPrice * GST_RATE;
    }

    public static double calculateFinalPrice(double totalPrice) {

        double gst = calculateGST(totalPrice);

        return totalPrice + gst;
    }
}