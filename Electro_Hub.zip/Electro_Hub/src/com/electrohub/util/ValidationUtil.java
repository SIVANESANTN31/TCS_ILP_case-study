package com.electrohub.util;

import java.time.LocalDate;
import java.time.Period;
import java.util.regex.Pattern;

public class ValidationUtil {

    private ValidationUtil() {
    }

    public static boolean isValidUsername(String username) {

        return username != null
                && username.trim().length() >= 3
                && username.trim().length() <= 30;
    }

    public static boolean isValidEmail(String email) {

        String regex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";

        return email != null
                && Pattern.matches(regex, email);
    }

    public static boolean isValidPassword(String password) {

        String regex =
                "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,20}$";

        return password != null
                && Pattern.matches(regex, password);
    }

    public static boolean isValidMobile(String mobile) {

        return mobile != null
                && mobile.matches("^[6-9]\\d{9}$");
    }

    public static boolean isAdult(LocalDate dob) {

        int age = Period.between(dob, LocalDate.now()).getYears();

        return age >= 18;
    }
}
