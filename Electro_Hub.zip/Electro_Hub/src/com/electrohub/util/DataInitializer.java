package com.electrohub.util;

import java.time.LocalDateTime;

import com.electrohub.enums.Category;
import com.electrohub.enums.ProductStatus;
import com.electrohub.model.Product;
import com.electrohub.repository.ProductRepository;

public class DataInitializer {

    private DataInitializer() {
    }

    public static void initializeProducts() {

        ProductRepository repository =
                ProductRepository.getInstance();

        if (!repository.findAll().isEmpty()) {
            return;
        }

        LocalDateTime now =
                LocalDateTime.now();

        repository.save(new Product(
                10001,
                "iPhone 15",
                "iphone.jpg",
                79999,
                25,
                Category.SMART_PHONE,
                ProductStatus.ACTIVE,
                now,
                now
        ));

        repository.save(new Product(
                10002,
                "Dell Inspiron",
                "dell.jpg",
                65000,
                75,
                Category.LAPTOP,
                ProductStatus.ACTIVE,
                now,
                now
        ));

        repository.save(new Product(
                10003,
                "Samsung Watch",
                "watch.jpg",
                15000,
                200,
                Category.SMART_WATCH,
                ProductStatus.ACTIVE,
                now,
                now
        ));

        repository.save(new Product(
                10004,
                "Gaming PC",
                "pc.jpg",
                95000,
                15,
                Category.PC,
                ProductStatus.ACTIVE,
                now,
                now
        ));

        repository.save(new Product(
                10005,
                "Lenovo Tablet",
                "tablet.jpg",
                22000,
                50,
                Category.TABLET,
                ProductStatus.ACTIVE,
                now,
                now
        ));
    }
}