package com.electrohub.util;

import java.util.Random;

public class IdGenerator {

    private static final Random random = new Random();

    private IdGenerator() {
    }

    public static int generateProductId() {
        return 10000 + random.nextInt(90000);
    }

    public static int generateCustomerId() {
        return 1000000 + random.nextInt(9000000);
    }

    public static int generateOrderId() {
        return 1000 + random.nextInt(9000);
    }

    public static int generatePaymentId() {
        return 10000 + random.nextInt(90000);
    }

    public static int generateAuditId() {
        return 1000 + random.nextInt(9000);
    }
}