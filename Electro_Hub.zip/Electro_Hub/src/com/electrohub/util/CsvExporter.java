package com.electrohub.util;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import com.electrohub.model.AuditLog;

public class CsvExporter {

    private CsvExporter() {
    }

    public static void exportAuditLogs(
            List<AuditLog> logs,
            String fileName) {

        try (FileWriter writer =
                     new FileWriter(fileName)) {

            writer.append(
                    "Id,Module,Operation,CreatedOn,CreatedBy,ModifiedOn,ModifiedBy\n");

            for (AuditLog log : logs) {

                writer.append(String.valueOf(log.getId()))
                        .append(",")

                        .append(log.getModule().name())
                        .append(",")

                        .append(log.getOperation().name())
                        .append(",")

                        .append(String.valueOf(log.getCreatedOn()))
                        .append(",")

                        .append(log.getCreatedBy())
                        .append(",")

                        .append(String.valueOf(log.getModifiedOn()))
                        .append(",")

                        .append(log.getModifiedBy())
                        .append("\n");
            }

            System.out.println(
                    "Audit Logs Exported Successfully."
            );

        } catch (IOException e) {

            System.out.println(
                    "Failed To Export Audit Logs."
            );
        }
    }
}