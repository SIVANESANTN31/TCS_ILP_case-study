package com.electrohub.repository;

import java.util.List;

import com.electrohub.datastore.DataStore;
import com.electrohub.model.Product;

public class ProductRepository {

    public void save(Product product) {

        DataStore.products.add(product);
    }

    public List<Product> findAll() {

        return DataStore.products;
    }

    public Product findById(int productId) {

        for (Product product : DataStore.products) {

            if (product.getProductId() == productId) {
                return product;
            }
        }

        return null;
    }

    public Product findByName(String productName) {

        for (Product product : DataStore.products) {

            if (product.getProductName()
                    .equalsIgnoreCase(productName)) {

                return product;
            }
        }

        return null;
    }

    public boolean update(Product updatedProduct) {

        for (int i = 0; i < DataStore.products.size(); i++) {

            if (DataStore.products.get(i).getProductId()
                    == updatedProduct.getProductId()) {

                DataStore.products.set(i, updatedProduct);

                return true;
            }
        }

        return false;
    }
    

private static final ProductRepository INSTANCE =
            new ProductRepository();

    private ProductRepository() {}

    public static ProductRepository getInstance() {
        return INSTANCE;
    }

}