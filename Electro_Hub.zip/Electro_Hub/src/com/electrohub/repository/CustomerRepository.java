package com.electrohub.repository;

import java.util.List;

import com.electrohub.datastore.DataStore;
import com.electrohub.model.Customer;

public class CustomerRepository {

    public void save(Customer customer) {
        DataStore.customers.add(customer);
    }

    public List<Customer> findAll() {
        return DataStore.customers;
    }

    public Customer findByEmail(String email) {

        for (Customer customer : DataStore.customers) {

            if (customer.getEmail().equalsIgnoreCase(email)) {
                return customer;
            }
        }

        return null;
    }

    public Customer findById(int customerId) {

        for (Customer customer : DataStore.customers) {

            if (customer.getCustomerId() == customerId) {
                return customer;
            }
        }

        return null;
    }

    public Customer findByUsername(String username) {

        for (Customer customer : DataStore.customers) {

            if (customer.getUsername().equalsIgnoreCase(username)) {
                return customer;
            }
        }

        return null;
    }

    public boolean update(Customer updatedCustomer) {

        for (int i = 0; i < DataStore.customers.size(); i++) {

            if (DataStore.customers.get(i).getCustomerId()
                    == updatedCustomer.getCustomerId()) {

                DataStore.customers.set(i, updatedCustomer);
                return true;
            }
        }

        return false;
    }
    

    private static final CustomerRepository INSTANCE =
               new CustomerRepository();

       private CustomerRepository() {}

       public static CustomerRepository getInstance() {
           return INSTANCE;
       }

}