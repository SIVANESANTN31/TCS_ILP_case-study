package com.electrohub.repository;

import java.util.List;

import com.electrohub.datastore.DataStore;
import com.electrohub.model.AuditLog;

public class AuditLogRepository {

    public void save(AuditLog auditLog) {

        DataStore.auditLogs.add(auditLog);
    }

    public List<AuditLog> findAll() {

        return DataStore.auditLogs;
    }
    

private static final AuditLogRepository INSTANCE =
            new AuditLogRepository();

    private AuditLogRepository(){}

    public static AuditLogRepository getInstance() {
        return INSTANCE;
    }

}