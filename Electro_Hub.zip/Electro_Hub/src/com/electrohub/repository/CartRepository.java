package com.electrohub.repository;

import java.util.HashMap;
import java.util.Map;

import com.electrohub.model.Cart;

public class CartRepository {

    private static final CartRepository INSTANCE =
            new CartRepository();

    private final Map<Integer, Cart> carts =
            new HashMap<>();

    private CartRepository() {
    }

    public static CartRepository getInstance() {
        return INSTANCE;
    }

    public void saveCart(int customerId,
                         Cart cart) {

        carts.put(customerId, cart);
    }

    public Cart getCart(int customerId) {

        return carts.get(customerId);
    }

    public boolean cartExists(int customerId) {

        return carts.containsKey(customerId);
    }

    public void removeCart(int customerId) {

        carts.remove(customerId);
    }

    public Map<Integer, Cart> getAllCarts() {

        return carts;
    }
}