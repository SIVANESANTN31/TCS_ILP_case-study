package com.electrohub.repository;

import java.util.List;

import com.electrohub.datastore.DataStore;
import com.electrohub.model.Payment;

public class PaymentRepository {

    public void save(Payment payment) {

        DataStore.payments.add(payment);
    }

    public List<Payment> findAll() {

        return DataStore.payments;
    }

    public Payment findById(int paymentId) {

        for (Payment payment : DataStore.payments) {

            if (payment.getPaymentId() == paymentId) {
                return payment;
            }
        }

        return null;
    }
    

private static final PaymentRepository INSTANCE =
            new PaymentRepository();

    private PaymentRepository() {}

    public static PaymentRepository getInstance() {
        return INSTANCE;
    }
    
    

}