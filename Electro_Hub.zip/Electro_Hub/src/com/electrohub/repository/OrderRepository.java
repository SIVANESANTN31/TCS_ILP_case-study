package com.electrohub.repository;

import java.util.ArrayList;
import java.util.List;

import com.electrohub.datastore.DataStore;
import com.electrohub.model.Order;

public class OrderRepository {

    public void save(Order order) {

        DataStore.orders.add(order);
    }

    public List<Order> findAll() {

        return DataStore.orders;
    }

    public Order findById(int orderId) {

        for (Order order : DataStore.orders) {

            if (order.getOrderId() == orderId) {
                return order;
            }
        }

        return null;
    }

    public List<Order> findByCustomerId(int customerId) {

        List<Order> customerOrders = new ArrayList<>();

        for (Order order : DataStore.orders) {

            if (order.getCustomer().getCustomerId()
                    == customerId) {

                customerOrders.add(order);
            }
        }

        return customerOrders;
    }
    

private static final OrderRepository INSTANCE =
            new OrderRepository();

    private OrderRepository(){}

    public static OrderRepository getInstance() {
        return INSTANCE;
    }

}