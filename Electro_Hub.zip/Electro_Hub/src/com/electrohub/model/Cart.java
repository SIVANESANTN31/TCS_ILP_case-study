package com.electrohub.model;

import java.util.ArrayList;
import java.util.List;

public class Cart {

    private int customerId;
    private List<CartItem> items;

    public Cart() {
        this.items = new ArrayList<>();
    }

    public Cart(int customerId) {
        this.customerId = customerId;
        this.items = new ArrayList<>();
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public List<CartItem> getItems() {
        return items;
    }

    public void setItems(List<CartItem> items) {
        this.items = items;
    }

    public double calculateTotalPrice() {

        double total = 0;

        for (CartItem item : items) {
            total += item.getItemTotal();
        }

        return total;
    }
}