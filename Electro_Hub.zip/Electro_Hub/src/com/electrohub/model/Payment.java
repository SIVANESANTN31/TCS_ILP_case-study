package com.electrohub.model;

import java.time.LocalDateTime;

import com.electrohub.enums.PaymentMode;
import com.electrohub.enums.PaymentStatus;

public class Payment {

    private int paymentId;

    private PaymentMode paymentMode;
    private int quantity;

    private double totalPrice;
    private double gstPrice;
    private double finalPrice;

    private PaymentStatus status;

    private LocalDateTime createdOn;
    private LocalDateTime modifiedOn;

    public Payment() {
    }

    public Payment(int paymentId,
                   PaymentMode paymentMode,
                   int quantity,
                   double totalPrice,
                   double gstPrice,
                   double finalPrice,
                   PaymentStatus status,
                   LocalDateTime createdOn,
                   LocalDateTime modifiedOn) {

        this.paymentId = paymentId;
        this.paymentMode = paymentMode;
        this.quantity = quantity;
        this.totalPrice = totalPrice;
        this.gstPrice = gstPrice;
        this.finalPrice = finalPrice;
        this.status = status;
        this.createdOn = createdOn;
        this.modifiedOn = modifiedOn;
    }

    public int getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(int paymentId) {
        this.paymentId = paymentId;
    }

    public PaymentMode getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(PaymentMode paymentMode) {
        this.paymentMode = paymentMode;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public double getGstPrice() {
        return gstPrice;
    }

    public void setGstPrice(double gstPrice) {
        this.gstPrice = gstPrice;
    }

    public double getFinalPrice() {
        return finalPrice;
    }

    public void setFinalPrice(double finalPrice) {
        this.finalPrice = finalPrice;
    }

    public PaymentStatus getStatus() {
        return status;
    }

    public void setStatus(PaymentStatus status) {
        this.status = status;
    }

    public LocalDateTime getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(LocalDateTime createdOn) {
        this.createdOn = createdOn;
    }

    public LocalDateTime getModifiedOn() {
        return modifiedOn;
    }

    public void setModifiedOn(LocalDateTime modifiedOn) {
        this.modifiedOn = modifiedOn;
    }

    @Override
    public String toString() {
        return "Payment{" +
                "paymentId=" + paymentId +
                ", paymentMode=" + paymentMode +
                ", finalPrice=" + finalPrice +
                ", status=" + status +
                '}';
    }
}