package com.electrohub.model;

import java.time.LocalDateTime;
import java.util.List;

import com.electrohub.enums.OrderStatus;

public class Order {

    private int orderId;

    private Customer customer;
    private List<CartItem> items;
    private Payment payment;

    private OrderStatus orderStatus;

    private LocalDateTime orderDate;

    public Order() {
    }

    public Order(int orderId,
                 Customer customer,
                 List<CartItem> items,
                 Payment payment,
                 OrderStatus orderStatus,
                 LocalDateTime orderDate) {

        this.orderId = orderId;
        this.customer = customer;
        this.items = items;
        this.payment = payment;
        this.orderStatus = orderStatus;
        this.orderDate = orderDate;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public List<CartItem> getItems() {
        return items;
    }

    public void setItems(List<CartItem> items) {
        this.items = items;
    }

    public Payment getPayment() {
        return payment;
    }

    public void setPayment(Payment payment) {
        this.payment = payment;
    }

    public OrderStatus getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(OrderStatus orderStatus) {
        this.orderStatus = orderStatus;
    }

    public LocalDateTime getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(LocalDateTime orderDate) {
        this.orderDate = orderDate;
    }

    @Override
    public String toString() {
        return "Order{" +
                "orderId=" + orderId +
                ", customer=" + customer.getUsername() +
                ", orderStatus=" + orderStatus +
                ", orderDate=" + orderDate +
                '}';
    }
}