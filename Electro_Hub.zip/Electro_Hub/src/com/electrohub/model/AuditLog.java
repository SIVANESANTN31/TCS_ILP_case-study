package com.electrohub.model;

import java.time.LocalDateTime;

import com.electrohub.enums.AuditModule;
import com.electrohub.enums.AuditOperation;

public class AuditLog {

    private int id;

    private AuditModule module;
    private AuditOperation operation;

    private LocalDateTime createdOn;
    private String createdBy;

    private LocalDateTime modifiedOn;
    private String modifiedBy;

    public AuditLog() {
    }

    public AuditLog(int id,
                    AuditModule module,
                    AuditOperation operation,
                    LocalDateTime createdOn,
                    String createdBy,
                    LocalDateTime modifiedOn,
                    String modifiedBy) {

        this.id = id;
        this.module = module;
        this.operation = operation;
        this.createdOn = createdOn;
        this.createdBy = createdBy;
        this.modifiedOn = modifiedOn;
        this.modifiedBy = modifiedBy;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public AuditModule getModule() {
        return module;
    }

    public void setModule(AuditModule module) {
        this.module = module;
    }

    public AuditOperation getOperation() {
        return operation;
    }

    public void setOperation(AuditOperation operation) {
        this.operation = operation;
    }

    public LocalDateTime getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(LocalDateTime createdOn) {
        this.createdOn = createdOn;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public LocalDateTime getModifiedOn() {
        return modifiedOn;
    }

    public void setModifiedOn(LocalDateTime modifiedOn) {
        this.modifiedOn = modifiedOn;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    @Override
    public String toString() {
        return "AuditLog{" +
                "id=" + id +
                ", module=" + module +
                ", operation=" + operation +
                ", createdBy='" + createdBy + '\'' +
                '}';
    }
}