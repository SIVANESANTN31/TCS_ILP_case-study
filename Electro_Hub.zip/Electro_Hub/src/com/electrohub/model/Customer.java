package com.electrohub.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.electrohub.enums.CustomerStatus;

public class Customer {

    private int customerId;
    private String username;
    private String email;
    private LocalDate dob;
    private String password;
    private long mobile;
    private String address;

    private CustomerStatus status;

    private LocalDateTime createdOn;
    private LocalDateTime modifiedOn;

    public Customer() {
    }

    public Customer(int customerId,
                    String username,
                    String email,
                    LocalDate dob,
                    String password,
                    long mobile,
                    String address,
                    CustomerStatus status,
                    LocalDateTime createdOn,
                    LocalDateTime modifiedOn) {

        this.customerId = customerId;
        this.username = username;
        this.email = email;
        this.dob = dob;
        this.password = password;
        this.mobile = mobile;
        this.address = address;
        this.status = status;
        this.createdOn = createdOn;
        this.modifiedOn = modifiedOn;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public LocalDate getDob() {
        return dob;
    }

    public void setDob(LocalDate dob) {
        this.dob = dob;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public long getMobile() {
        return mobile;
    }

    public void setMobile(long mobile) {
        this.mobile = mobile;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public CustomerStatus getStatus() {
        return status;
    }

    public void setStatus(CustomerStatus status) {
        this.status = status;
    }

    public LocalDateTime getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(LocalDateTime createdOn) {
        this.createdOn = createdOn;
    }

    public LocalDateTime getModifiedOn() {
        return modifiedOn;
    }

    public void setModifiedOn(LocalDateTime modifiedOn) {
        this.modifiedOn = modifiedOn;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "customerId=" + customerId +
                ", username='" + username + '\'' +
                ", email='" + email + '\'' +
                ", mobile=" + mobile +
                ", status=" + status +
                '}';
    }
}