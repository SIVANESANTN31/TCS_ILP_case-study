package com.electrohub.model;

import com.electrohub.enums.Role;

public class UserSession {

    private String username;
    private Role role;
    private boolean loggedIn;

    public UserSession() {
    }

    public UserSession(String username, Role role, boolean loggedIn) {
        this.username = username;
        this.role = role;
        this.loggedIn = loggedIn;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public boolean isLoggedIn() {
        return loggedIn;
    }

    public void setLoggedIn(boolean loggedIn) {
        this.loggedIn = loggedIn;
    }

    @Override
    public String toString() {
        return "UserSession{" +
                "username='" + username + '\'' +
                ", role=" + role +
                ", loggedIn=" + loggedIn +
                '}';
    }
}