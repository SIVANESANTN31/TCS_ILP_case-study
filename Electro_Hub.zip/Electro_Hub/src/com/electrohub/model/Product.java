package com.electrohub.model;

import java.time.LocalDateTime;

import com.electrohub.enums.Category;
import com.electrohub.enums.ProductStatus;

public class Product {

    private int productId;
    private String productName;
    private String productImage;
    private double price;
    private int stock;

    private Category category;
    private ProductStatus status;

    private LocalDateTime createdOn;
    private LocalDateTime modifiedOn;

    public Product() {
    }

    public Product(int productId,
                   String productName,
                   String productImage,
                   double price,
                   int stock,
                   Category category,
                   ProductStatus status,
                   LocalDateTime createdOn,
                   LocalDateTime modifiedOn) {

        this.productId = productId;
        this.productName = productName;
        this.productImage = productImage;
        this.price = price;
        this.stock = stock;
        this.category = category;
        this.status = status;
        this.createdOn = createdOn;
        this.modifiedOn = modifiedOn;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductImage() {
        return productImage;
    }

    public void setProductImage(String productImage) {
        this.productImage = productImage;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public ProductStatus getStatus() {
        return status;
    }

    public void setStatus(ProductStatus status) {
        this.status = status;
    }

    public LocalDateTime getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(LocalDateTime createdOn) {
        this.createdOn = createdOn;
    }

    public LocalDateTime getModifiedOn() {
        return modifiedOn;
    }

    public void setModifiedOn(LocalDateTime modifiedOn) {
        this.modifiedOn = modifiedOn;
    }

    @Override
    public String toString() {
        return "Product{" +
                "productId=" + productId +
                ", productName='" + productName + '\'' +
                ", price=" + price +
                ", stock=" + stock +
                ", category=" + category +
                ", status=" + status +
                '}';
    }
}