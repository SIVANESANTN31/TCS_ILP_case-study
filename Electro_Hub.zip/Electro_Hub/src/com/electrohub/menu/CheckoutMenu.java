package com.electrohub.menu;

import java.util.Scanner;

import com.electrohub.enums.PaymentMode;
import com.electrohub.model.Customer;
import com.electrohub.model.Order;
import com.electrohub.service.InvoiceService;
import com.electrohub.service.PaymentService;

public class CheckoutMenu {

    private final Scanner scanner =
            new Scanner(System.in);

    private final PaymentService paymentService =
            new PaymentService();

    private final InvoiceService invoiceService =
            new InvoiceService();

    public void checkout(Customer customer) {

        System.out.println();
        System.out.println("========= CHECKOUT =========");
        System.out.println("1. UPI");
        System.out.println("2. DEBIT CARD");
        System.out.println("3. CREDIT CARD");

        int choice =
                Integer.parseInt(scanner.nextLine());

        PaymentMode mode;

        switch (choice) {

            case 1:
                mode = PaymentMode.UPI;
                break;

            case 2:
                mode = PaymentMode.DEBIT_CARD;
                break;

            case 3:
                mode = PaymentMode.CREDIT_CARD;
                break;

            default:
                System.out.println("Invalid Option");
                return;
        }

        Order order =
                paymentService.checkout(
                        customer,
                        mode
                );

        if (order != null) {

            invoiceService.generateInvoice(
                    order
            );
        }
    }
}