package com.electrohub.menu;

import java.util.List;
import java.util.Scanner;

import com.electrohub.model.Product;
import com.electrohub.service.CustomerCatalogService;

public class CustomerCatalogMenu {

    private final Scanner scanner =
            new Scanner(System.in);

    private final CustomerCatalogService
            catalogService =
            new CustomerCatalogService();

    public void showCatalog() {

        while (true) {

            System.out.println();
            System.out.println("===== CATALOG =====");
            System.out.println("1. View Products");
            System.out.println("2. Search Product");
            System.out.println("3. Product Details");
            System.out.println("4. Back");

            int choice =
                    Integer.parseInt(
                            scanner.nextLine()
                    );

            switch (choice) {

                case 1:

                    List<Product> products =
                            catalogService.viewCatalog();

                    products.forEach(
                            System.out::println
                    );

                    break;

                case 2:

                    System.out.print(
                            "Keyword : "
                    );

                    String keyword =
                            scanner.nextLine();

                    catalogService
                            .searchProducts(
                                    keyword
                            )
                            .forEach(
                                    System.out::println
                            );

                    break;

                case 3:

                    System.out.print(
                            "Product ID : "
                    );

                    int id =
                            Integer.parseInt(
                                    scanner.nextLine()
                            );

                    System.out.println(
                            catalogService
                                    .getProductDetails(
                                            id
                                    )
                    );

                    break;

                case 4:
                    return;

                default:
                    System.out.println(
                            "Invalid Choice"
                    );
            }
        }
    }
}