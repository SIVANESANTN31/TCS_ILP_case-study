package com.electrohub.menu;

import com.electrohub.service.AuditService;

public class AuditMenu {

    private final AuditService auditService =
            new AuditService();

    public void show() {

        auditService.viewAuditLogs();
    }
}