package com.electrohub.menu;

import java.time.LocalDate;
import java.util.Scanner;

import com.electrohub.service.CustomerService;

public class ProfileMenu {

    private final Scanner scanner =
            new Scanner(System.in);

    private final CustomerService service =
            new CustomerService();

    public void updateProfile(
            int customerId) {

        System.out.print(
                "Email : "
        );

        String email =
                scanner.nextLine();

        System.out.print(
                "Password : "
        );

        String password =
                scanner.nextLine();

        System.out.print(
                "Mobile : "
        );

        String mobile =
                scanner.nextLine();

        System.out.print(
                "DOB (yyyy-MM-dd): "
        );

        LocalDate dob =
                LocalDate.parse(
                        scanner.nextLine()
                );

        System.out.print(
                "Address : "
        );

        String address =
                scanner.nextLine();

        service.updateProfile(
                customerId,
                email,
                password,
                mobile,
                dob,
                address
        );
    }
}