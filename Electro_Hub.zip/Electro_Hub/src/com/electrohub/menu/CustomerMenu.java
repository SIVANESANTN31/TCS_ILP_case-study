package com.electrohub.menu;

import java.util.Scanner;

import com.electrohub.model.Customer;
import com.electrohub.service.CustomerService;

public class CustomerMenu {

    private final Scanner scanner =
            new Scanner(System.in);

    private final CustomerCatalogMenu catalogMenu =
            new CustomerCatalogMenu();

    private final CartMenu cartMenu =
            new CartMenu();

    private final CheckoutMenu checkoutMenu =
            new CheckoutMenu();

    private final OrderHistoryMenu orderMenu =
            new OrderHistoryMenu();

    private final ProfileMenu profileMenu =
            new ProfileMenu();

    private final CustomerService customerService =
            new CustomerService();

    private final Customer customer;

    public CustomerMenu(Customer customer) {

        this.customer = customer;
    }

    public void show() {

        while (true) {

            System.out.println();
            System.out.println("====== CUSTOMER MENU ======");
            System.out.println("1. Product Catalog");
            System.out.println("2. Cart");
            System.out.println("3. Checkout");
            System.out.println("4. Order History");
            System.out.println("5. Update Profile");
            System.out.println("6. Logout");

            int choice =
                    Integer.parseInt(
                            scanner.nextLine()
                    );

            switch (choice) {

                case 1:

                    catalogMenu.showCatalog();
                    break;

                case 2:

                    cartMenu.show(
                            customer.getCustomerId()
                    );
                    break;

                case 3:

                    checkoutMenu.checkout(
                            customer
                    );

                    break;

                case 4:

                    orderMenu.show(
                            customer.getCustomerId()
                    );

                    break;

                case 5:

                    profileMenu.updateProfile(
                            customer.getCustomerId()
                    );

                    break;

                case 6:

                    return;

                default:

                    System.out.println(
                            "Invalid Choice"
                    );
            }
        }
    }
}