package com.electrohub.menu;

import com.electrohub.service.OrderService;

public class PurchaseHistoryMenu {

    private final OrderService orderService =
            new OrderService();

    public void show() {

        orderService.viewAllOrders();
    }
}