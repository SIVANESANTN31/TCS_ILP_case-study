package com.electrohub.menu;

import java.util.Scanner;

import com.electrohub.service.CustomerService;

public class CustomerManagementMenu {

    private final Scanner scanner =
            new Scanner(System.in);

    private final CustomerService customerService =
            new CustomerService();

    public void show(String adminName) {

        while (true) {

            System.out.println();
            System.out.println("===== CUSTOMERS =====");
            System.out.println("1. View Customers");
            System.out.println("2. Activate Customer");
            System.out.println("3. Back");

            int choice =
                    Integer.parseInt(scanner.nextLine());

            switch (choice) {

                case 1:
                    customerService.viewAllCustomers();
                    break;

                case 2:

                    System.out.print(
                            "Customer ID : "
                    );

                    int id =
                            Integer.parseInt(
                                    scanner.nextLine()
                            );

                    customerService
                            .activateCustomer(
                                    id,
                                    adminName
                            );

                    break;

                case 3:
                    return;

                default:
                    System.out.println(
                            "Invalid Choice"
                    );
            }
        }
    }
}