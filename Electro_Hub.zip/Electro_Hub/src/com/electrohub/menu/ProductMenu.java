package com.electrohub.menu;

import java.util.Scanner;

import com.electrohub.enums.Category;
import com.electrohub.service.ProductService;

public class ProductMenu {

    private final Scanner scanner =
            new Scanner(System.in);

    private final ProductService productService =
            new ProductService();

    public void showProductMenu(String adminName) {

        while (true) {

            System.out.println();
            System.out.println("========== PRODUCT MENU ==========");
            System.out.println("1. Add Product");
            System.out.println("2. View Products");
            System.out.println("3. Soft Delete Product");
            System.out.println("4. Update Product Price");
            System.out.println("5. Back");
            System.out.print("Choice : ");

            int choice =
                    Integer.parseInt(scanner.nextLine());

            switch (choice) {

                case 1:
                    addProduct(adminName);
                    break;

                case 2:
                    productService.viewAllProducts();
                    break;

                case 3:
                    deleteProduct(adminName);
                    break;

                case 4:
                    updatePrice(adminName);
                    break;

                case 5:
                    return;

                default:
                    System.out.println("Invalid Choice.");
            }
        }
    }

    private void addProduct(String adminName) {

        try {

            System.out.print("Product Name : ");
            String name =
                    scanner.nextLine();

            System.out.print("Image Path : ");
            String image =
                    scanner.nextLine();

            System.out.print("Price : ");
            double price =
                    Double.parseDouble(scanner.nextLine());

            System.out.print("Stock : ");
            int stock =
                    Integer.parseInt(scanner.nextLine());

            System.out.println();
            System.out.println("Categories");
            System.out.println("1. SMART_PHONE");
            System.out.println("2. LAPTOP");
            System.out.println("3. PC");
            System.out.println("4. SMART_WATCH");
            System.out.println("5. TABLET");

            int option =
                    Integer.parseInt(scanner.nextLine());

            Category category =
                    getCategory(option);

            productService.addProduct(
                    name,
                    image,
                    price,
                    stock,
                    category,
                    adminName
            );

        }
        catch (Exception e) {

            System.out.println("Invalid Input.");
        }
    }

    private void deleteProduct(String adminName) {

        System.out.print("Product ID : ");

        int productId =
                Integer.parseInt(scanner.nextLine());

        productService.softDeleteProduct(
                productId,
                adminName
        );
    }

    private void updatePrice(String adminName) {

        System.out.print("Product ID : ");

        int productId =
                Integer.parseInt(scanner.nextLine());

        System.out.println(
                "Enter 0 for Dynamic Pricing"
        );

        System.out.print("Price : ");

        double price =
                Double.parseDouble(scanner.nextLine());

        productService.updatePrice(
                productId,
                price,
                adminName
        );
    }

    private Category getCategory(int choice) {

        switch (choice) {

            case 1:
                return Category.SMART_PHONE;

            case 2:
                return Category.LAPTOP;

            case 3:
                return Category.PC;

            case 4:
                return Category.SMART_WATCH;

            case 5:
                return Category.TABLET;

            default:
                throw new IllegalArgumentException(
                        "Invalid Category"
                );
        }
    }
}