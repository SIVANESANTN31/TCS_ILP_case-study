package com.electrohub.menu;

import java.time.LocalDate;
import java.util.Scanner;

import com.electrohub.model.Customer;
import com.electrohub.service.AuthService;
import com.electrohub.service.CustomerService;
import com.electrohub.util.ConsolePrinter;

public class MainMenu {

    private final Scanner scanner =
            new Scanner(System.in);

    private final AuthService authService =
            new AuthService();

    private final CustomerService customerService =
            new CustomerService();

    public void show() {

        while (true) {

            ConsolePrinter.printHeader(
                    "Electro Hub"
            );

            System.out.println("1. Admin Login");
            System.out.println("2. Customer Login");
            System.out.println("3. Customer Registration");
            System.out.println("4. Exit");

            System.out.print(
                    "Enter Choice : "
            );

            try {

                int choice =
                        Integer.parseInt(
                                scanner.nextLine()
                        );

                switch (choice) {

                    case 1:
                        adminLogin();
                        break;

                    case 2:
                        customerLogin();
                        break;

                    case 3:
                        customerRegistration();
                        break;

                    case 4:

                        System.out.println(
                                "Thank You For Using ElectroHub"
                        );

                        System.exit(0);

                    default:

                        System.out.println(
                                "Invalid Choice."
                        );
                }

            } catch (NumberFormatException e) {

                System.out.println(
                        "Please Enter A Valid Number."
                );
            }
        }
    }

    private void adminLogin() {

        System.out.println();
        System.out.println(
                "===== ADMIN LOGIN ====="
        );

        System.out.print("Username : ");
        String username =
                scanner.nextLine();

        System.out.print("Password : ");
        String password =
                scanner.nextLine();

        if (authService.adminLogin(
                username,
                password
        ) != null) {

            AdminMenu adminMenu =
                    new AdminMenu(
                            authService
                    );

            adminMenu.show();
        }
    }

    private void customerLogin() {

        System.out.println();
        System.out.println(
                "===== CUSTOMER LOGIN ====="
        );

        System.out.print("Email : ");
        String email =
                scanner.nextLine();

        System.out.print("Password : ");
        String password =
                scanner.nextLine();

        if (authService.customerLogin(
                email,
                password
        ) != null) {

            Customer customer =
                    customerService
                            .getCustomerByEmail(
                                    email
                            );

            CustomerMenu customerMenu =
                    new CustomerMenu(
                            customer
                    );

            customerMenu.show();
        }
    }

    private void customerRegistration() {

        try {

            System.out.println();
            System.out.println(
                    "===== CUSTOMER REGISTRATION ====="
            );

            System.out.print(
                    "Username : "
            );
            String username =
                    scanner.nextLine();

            System.out.print(
                    "Email : "
            );
            String email =
                    scanner.nextLine();

            System.out.print(
                    "DOB (yyyy-MM-dd) : "
            );
            LocalDate dob =
                    LocalDate.parse(
                            scanner.nextLine()
                    );

            System.out.print(
                    "Password : "
            );
            String password =
                    scanner.nextLine();

            System.out.print(
                    "Mobile : "
            );
            String mobile =
                    scanner.nextLine();

            System.out.print(
                    "Address : "
            );
            String address =
                    scanner.nextLine();

            customerService.registerCustomer(
                    username,
                    email,
                    dob,
                    password,
                    mobile,
                    address
            );

        } catch (Exception e) {

            System.out.println(
                    "Invalid Input."
            );
        }
    }
}