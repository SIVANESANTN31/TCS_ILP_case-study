package com.electrohub.menu;

import java.util.Scanner;

import com.electrohub.service.CartService;

public class CartMenu {

    private final Scanner scanner =
            new Scanner(System.in);

    private final CartService cartService =
            new CartService();

    public void show(int customerId) {

        while (true) {

            System.out.println();
            System.out.println("===== CART =====");
            System.out.println("1. Add Product");
            System.out.println("2. Remove Product");
            System.out.println("3. View Cart");
            System.out.println("4. Back");

            int choice =
                    Integer.parseInt(
                            scanner.nextLine()
                    );

            switch (choice) {

                case 1:

                    System.out.print(
                            "Product Id : "
                    );

                    int productId =
                            Integer.parseInt(
                                    scanner.nextLine()
                            );

                    System.out.print(
                            "Quantity : "
                    );

                    int qty =
                            Integer.parseInt(
                                    scanner.nextLine()
                            );

                    cartService.addToCart(
                            customerId,
                            productId,
                            qty
                    );

                    break;

                case 2:

                    System.out.print(
                            "Product Id : "
                    );

                    int removeId =
                            Integer.parseInt(
                                    scanner.nextLine()
                            );

                    cartService
                            .removeFromCart(
                                    customerId,
                                    removeId
                            );

                    break;

                case 3:

                    cartService.viewCart(
                            customerId
                    );

                    break;

                case 4:

                    return;
            }
        }
    }
}