package com.electrohub.menu;

import java.util.Scanner;

import com.electrohub.service.AuditService;
import com.electrohub.service.AuthService;

public class AdminMenu {

    private final Scanner scanner =
            new Scanner(System.in);

    private final ProductMenu productMenu =
            new ProductMenu();

    private final CustomerManagementMenu
            customerManagementMenu =
            new CustomerManagementMenu();

    private final PurchaseHistoryMenu
            purchaseHistoryMenu =
            new PurchaseHistoryMenu();

    private final AuditService auditService =
            new AuditService();

    private final AuthService authService;

    public AdminMenu(
            AuthService authService) {

        this.authService = authService;
    }

    public void show() {

        while (true) {

            System.out.println();
            System.out.println("====== ADMIN MENU ======");
            System.out.println(
                    "1. Product Management");
            System.out.println(
                    "2. Customer Management");
            System.out.println(
                    "3. Purchase History");
            System.out.println(
                    "4. View Audit Logs");
            System.out.println(
                    "5. Export Audit Logs");
            System.out.println(
                    "6. Logout");

            int choice =
                    Integer.parseInt(
                            scanner.nextLine()
                    );

            String adminName =
                    authService
                            .getCurrentSession()
                            .getUsername();

            switch (choice) {

                case 1:

                    productMenu.showProductMenu(
                            adminName
                    );

                    break;

                case 2:

                    customerManagementMenu.show(
                            adminName
                    );

                    break;

                case 3:

                    purchaseHistoryMenu.show();
                    break;

                case 4:

                    auditService.viewAuditLogs();
                    break;

                case 5:

                    auditService
                            .exportAuditLogs();

                    break;

                case 6:

                    authService.logout();
                    return;

                default:

                    System.out.println(
                            "Invalid Choice"
                    );
            }
        }
    }
}