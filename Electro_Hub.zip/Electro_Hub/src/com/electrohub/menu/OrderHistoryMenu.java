package com.electrohub.menu;

import com.electrohub.service.OrderService;

public class OrderHistoryMenu {

    private final OrderService orderService =
            new OrderService();

    public void show(int customerId) {

        orderService.viewOrderHistory(
                customerId
        );
    }
}